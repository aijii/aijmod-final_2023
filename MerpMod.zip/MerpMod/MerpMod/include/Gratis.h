// Gratis Release  configuration

///////////////////////////////
//		HACK CONFIGURATION	//
//////////////////////////////
							//
#define MEMORY_HACKS 1		//
#define SD_HACKS	1		//
#define REVLIM_HACKS 1		//
#define	LC_ADJ_HACKS 0		//
#define PROG_MODE 0			//
#define SPARK_HACKS 0		//
#define CEL_HACKS 0			//
#define BOOST_HACKS 0		//
#define TIMING_HACKS 0		//
#define POLF_HACKS 0		//
#define PGWG_HACKS 0		//
#define INJECTOR_HACKS 0	//
							//
//////////////////////////////
