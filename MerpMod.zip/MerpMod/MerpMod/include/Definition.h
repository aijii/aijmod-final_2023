#include "EcuHacks.h"

const RamVariables * rmv;

const RamVariables *rmv = (RamVariables*)0xFFFF96D0 ;